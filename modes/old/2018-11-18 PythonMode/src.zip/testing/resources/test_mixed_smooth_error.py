# should throw a mixed smooth exception

background(0)
noStroke()
smooth()
ellipse(30, 48, 36, 36)
noSmooth()
ellipse(70, 48, 36, 36)