def settings():
	size(48, 48, P2D)

def draw():
    print 'OK'
    exit()
